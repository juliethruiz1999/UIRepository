package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import view.MainWindow;

public class ControllerApp implements ActionListener {
	
	private MainWindow main;

	
	public ControllerApp() {
		main = new MainWindow(this);
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		switch (Action.valueOf(e.getActionCommand())) {
		case SHOW_STORY_PANEL:
			showStoryPanel();
			break;
		case SHOW_CENTER_PANEL:
			showCenterPanel();
		case CHANGE_RED_PANEL:
			changeRedPanel();
		default:
			break;
		}
	}
	
	private void changeRedPanel() {
		main.changeStoryPanel();
	}


	private void showCenterPanel() {
		main.showCenterPanel();
		main.update();
	}


	private void showStoryPanel() {
		main.showStoryPanel();
		main.update();
	}
}
