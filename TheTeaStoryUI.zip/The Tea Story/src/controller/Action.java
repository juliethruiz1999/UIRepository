package controller;

public enum Action {
	SHOW_STORY_PANEL, SHOW_CENTER_PANEL,CHANGE_RED_PANEL

}
