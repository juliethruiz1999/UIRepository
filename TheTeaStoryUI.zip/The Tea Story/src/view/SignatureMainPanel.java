package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class SignatureMainPanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public SignatureMainPanel(ActionListener listener) {
		setBackground(Color.WHITE);
		setLayout(new BorderLayout());
		
		SignTopPanel signTopPanel = new SignTopPanel(listener);
		signTopPanel.setBackground(Color.WHITE);
		add(signTopPanel, BorderLayout.NORTH);

		JScrollPane scroll = new JScrollPane();
		SignScrollPanel signScrollPanel = new SignScrollPanel();
		add(signScrollPanel, BorderLayout.CENTER);
		scroll.setViewportView(signScrollPanel);
		add(scroll);
	}
	
}
