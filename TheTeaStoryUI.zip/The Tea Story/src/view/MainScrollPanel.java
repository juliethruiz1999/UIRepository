package view;

import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class MainScrollPanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public MainScrollPanel(ActionListener listener) {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		PanelBanner banner = new PanelBanner();
		panel.add(banner);
		
		PanelCenterCenter center = new PanelCenterCenter();
		panel.add(center);
		
		add(panel);
		
		PanelSouth sur = new PanelSouth();
		add(sur);
	}
}
