package view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class CenterPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	
	public CenterPanel(ActionListener listener) {
		setLayout(new BorderLayout());
		
		NorthPanel norte = new NorthPanel(listener);
		add(norte, BorderLayout.NORTH);
	
		JScrollPane scroll = new JScrollPane();
		MainScrollPanel mainScrollPanel = new MainScrollPanel(listener);
		add(mainScrollPanel, BorderLayout.CENTER);
		scroll.setViewportView(mainScrollPanel);
		add(scroll);
		
	}
}
