package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelMovil extends JPanel{

	private static final long serialVersionUID = 1L;

	public PanelMovil(String path , String name , String price) {
		setBackground(Color.WHITE);
		JPanel panel1 = new JPanel();
		
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
		panel1.setBackground(Color.WHITE);
		JButton btn = new JButton(new ImageIcon(getClass().getResource(path)));
		btn.setContentAreaFilled(false);
		btn.setOpaque(false);
		btn.setBorder(null);
		panel1.add(btn);
		
		JLabel lbl = new JLabel(name);
		lbl.setFont(new Font("sans-serif", Font.PLAIN, 15));
		panel1.add(lbl);
		
		JLabel lbl1 = new JLabel(price);
		lbl1.setFont(new Font("sans-serif", Font.PLAIN, 15));
		panel1.add(lbl1);
		
		add(panel1);
	}
}
