package view;

	import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
	import javax.swing.JMenu;
	import javax.swing.JMenuBar;
	import javax.swing.JMenuItem;
import javax.swing.SwingConstants;
import javax.swing.UIManager;


import controller.Action;

	public class JMenuBarWindow extends JMenuBar {
		
			private static final long serialVersionUID = 1L;
			private JMenu jMenuInit;
	        private JMenu jMenuReport;
	        private JMenu jMenuGalery;
	        private JMenu jMenuHelp;
	        private JMenu jMenuBlog;
	        private JMenuItem mision;
	        private JMenuItem politica;
	        private JMenuItem regulacion;
	        
		public JMenuBarWindow(ActionListener listener) {
			
			setBackground(Color.WHITE);
			
			setIUManager();
			init(listener);
		}
		
		
		private void setIUManager() {
			UIManager.put("MenuItem.background", Color.decode("#E8E8E8"));
			UIManager.put("MenuItem.font", new Font("Raleway", Font.PLAIN, 16));
			UIManager.put("MenuItem.foreground", Color.BLACK);
			UIManager.put("Menu.foreground", Color.BLACK);
			UIManager.put("Menu.font", new Font("Microsoft PhagsPa", Font.PLAIN, 16));
			UIManager.put("Menu.border", BorderFactory.createEmptyBorder(0, 30, 0, 30));
		}

		private void init(ActionListener listener) {
			jMenuInit = new JMenu("HOME");
			jMenuInit.setCursor(new Cursor(Cursor.HAND_CURSOR));
			add(jMenuInit);
	                
			jMenuReport = new JMenu("OUR STORY");
			jMenuReport.addActionListener(listener);
			add(jMenuReport);
		
			
			jMenuGalery = new JMenu("EXOTIC TEAS");
			jMenuGalery.setFocusable(false);
			mision = new JMenuItem("Signature blends");
			mision.setHorizontalAlignment(SwingConstants.CENTER);
			mision.setCursor(new Cursor(Cursor.HAND_CURSOR));
			mision.addActionListener(listener);
			mision.setActionCommand(Action.SHOW_STORY_PANEL.toString());
			jMenuGalery.add(mision);
			jMenuGalery.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
			
	        politica = new JMenuItem("Exclusive blends");
	        politica.setHorizontalAlignment(SwingConstants.CENTER);
	        politica.setCursor(new Cursor(Cursor.HAND_CURSOR));
	        jMenuGalery.add(politica);
	        
	        regulacion = new JMenuItem("Special blends");
	        regulacion.setHorizontalAlignment(SwingConstants.CENTER);
	        regulacion.setCursor(new Cursor(Cursor.HAND_CURSOR));
	        jMenuGalery.add(regulacion);
	        
	    	add(jMenuGalery);
	        
	        jMenuHelp = new JMenu("PACKAGING");
	        jMenuHelp.setCursor(new Cursor(Cursor.HAND_CURSOR));
			add(jMenuHelp);
			
		    jMenuBlog = new JMenu("BLOG");
		    jMenuBlog.setCursor(new Cursor(Cursor.HAND_CURSOR));
			add(jMenuBlog);
	       
		}

		
	}
