package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SignTopPanel extends JPanel{
	private static final long serialVersionUID = 1L;

	public SignTopPanel(ActionListener listener) {
		setBackground(Color.WHITE);
//		JPanel arribaTea = new JPanel();
//		arribaTea.setLayout(new BoxLayout(arribaTea, BoxLayout.Y_AXIS));
//		
		JPanel panelito = new JPanel();
		
		panelito.setLayout(new BoxLayout(panelito, BoxLayout.Y_AXIS));
		
		JLabel imageLabel = new JLabel();
		imageLabel.setIcon(new ImageIcon(getClass().getResource("/img/titleImage.png")));
		imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 400, 20, 10));
		panelito.add(imageLabel);
		panelito.setBackground(Color.white);
		
		JPanel panelitoito = new JPanel();
		panelitoito.setBackground(Color.WHITE);
		JMenuBarWindow menudito = new JMenuBarWindow(listener);
		panelitoito.add(menudito);
		panelito.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
		
		panelito.add(panelitoito);
		add(panelito);
		
		JPanel panelitoSocial = new JPanel();
		
		JButton btnBolsita = new JButton(new ImageIcon(getClass().getResource("/img/Captura.JPG")));
		btnBolsita.setOpaque(false);
		btnBolsita.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
		btnBolsita.setFocusable(false);
		btnBolsita.setContentAreaFilled(false);
		btnBolsita.setCursor(new Cursor(Cursor.HAND_CURSOR));
		panelitoSocial.add(btnBolsita);
		
		JLabel labelinea = new JLabel(new ImageIcon(getClass().getResource("/img/linea.JPG")));
		labelinea.setFocusable(false);
		panelitoSocial.add(labelinea);
		
		JButton btnFb = new JButton(new ImageIcon(getClass().getResource("/img/fb.JPG")));
		btnFb.setOpaque(false);
		btnFb.setFocusable(false);
		btnFb.setContentAreaFilled(false);
		btnFb.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnFb.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
		panelitoSocial.add(btnFb);
		
		JButton btnIg = new JButton(new ImageIcon(getClass().getResource("/img/insta.JPG")));
		btnIg.setOpaque(false);
		btnIg.setFocusable(false);
		btnIg.setContentAreaFilled(false);
		btnIg.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnIg.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
		panelitoSocial.add(btnIg);
		
		panelitoSocial.setBackground(Color.WHITE);
		add(panelitoSocial);
	}
}
