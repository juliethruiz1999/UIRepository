package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelSouth extends JPanel{

	private static final long serialVersionUID = 1L;
	
	public PanelSouth() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBackground(Color.decode("#5D2313"));
		
		JPanel panito = new JPanel();
		panito.setOpaque(false);
		panito.setLayout(new GridLayout(1 , 3));
		PanelBottom panB = new PanelBottom("Support", "Contacts", "Our stores");
		panito.add(panB);
		
		PanelBottom panC = new PanelBottom("Help", "Shipping and Returns", "Store Policy");
		panito.add(panC);
		
		PanelBottom panA = new PanelBottom("Follow Us", "Facebook", "Instagram");
		panito.add(panA);
		
		panito.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 60));
		add(panito);
		
		JPanel panelito = new JPanel();
		panelito.setOpaque(false);
		
		JTextField field = new JTextField("Email Address");
		field.setPreferredSize(new Dimension(830, 35));
		panelito.add(field);
		
		JButton btn = new JButton("Suscribe Now");
		btn.setFont(new Font("Arial", Font.PLAIN, 20));
		btn.setForeground(Color.WHITE);
		btn.setBackground(Color.decode("#8E655A"));
		panelito.add(btn);
		
		add(panelito);
		
		JPanel pane = new JPanel();
		pane.setOpaque(false);
		pane.setBorder(BorderFactory.createMatteBorder(2, 0, 0, 0, Color.WHITE));
		
		JLabel lbl1 = new JLabel("@2018 by Brewing Gold Private Limited. All Rights Reserved");
		lbl1.setForeground(Color.WHITE);
		lbl1.setFont(new Font("raleway", Font.PLAIN, 12));
		pane.add(lbl1);
		add(pane);
	}
}
