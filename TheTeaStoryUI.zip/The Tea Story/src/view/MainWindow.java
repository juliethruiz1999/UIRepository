package view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class MainWindow extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private SignatureMainPanel storyPanel;
	private CenterPanel centro;
	
	public MainWindow(ActionListener listener) {
		setIconImage(new ImageIcon(getClass().getResource("/img/icono.png")).getImage());
		setTitle("theteastory");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(MAXIMIZED_BOTH);
		
		centro = new CenterPanel(listener);
		add(centro);
		
		init(listener);
		setVisible(true);
		
		
	}
	
	private void init(ActionListener listener) {
		storyPanel = new SignatureMainPanel(listener);
	}

	public SignatureMainPanel getStoryPanel(){
		return storyPanel;
	}
	
	public void showCenterPanel() {
		getContentPane().removeAll();
		getContentPane().add(centro, BorderLayout.CENTER);
		centro.setVisible(true);
	}

	
	public void showStoryPanel() {
		getContentPane().removeAll();
		getContentPane().add(storyPanel, BorderLayout.CENTER);
		
		storyPanel.setVisible(true);
	}
	
	public void update() {
		repaint();
		setVisible(true);
	}
	
	public void changeStoryPanel() {
		storyPanel.setVisible(true);
		centro.setVisible(false);
		setVisible(true);
		repaint();
		revalidate();
	}
}
