package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelCenterCenter extends JPanel{


	private static final long serialVersionUID = 1L;

	public PanelCenterCenter() {

		setBackground(Color.WHITE);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JLabel lbl1 = new JLabel("EXCLUSIVELY HANDCRAFTED TEAS");
		lbl1.setFont(new Font("Baskerville Old Face", Font.BOLD, 40));
		lbl1.setForeground(Color.decode("#5D2313"));
		lbl1.setAlignmentX(CENTER_ALIGNMENT);
		lbl1.setBorder(BorderFactory.createEmptyBorder(20, 0, 30, 0));
		add(lbl1);
		
		JLabel lbl2 = new JLabel("Indulge in the ultimate tea experience with our exotic");
		lbl2.setFont(new Font("Baskerville Old Face", Font.BOLD, 17));
		lbl2.setAlignmentX(CENTER_ALIGNMENT);
		lbl2.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
		lbl2.setForeground(Color.decode("#5D2313"));
		add(lbl2);
		
		JLabel lbl3 = new JLabel("blends exclusively handcrafted in Singapore!");
		lbl3.setFont(new Font("Baskerville Old Face", Font.BOLD, 17));
		lbl3.setAlignmentX(CENTER_ALIGNMENT);	
		lbl3.setForeground(Color.decode("#5D2313"));
		add(lbl3);
		
		JPanel panel3 = new JPanel();
		panel3.setLayout(new GridLayout(0, 4));
		panel3.setBackground(Color.WHITE);
		
		PanelMovil panel = new PanelMovil("/img/Plato1.JPG", "            Fruity Sangria", "                $5.50");
		panel3.add(panel);
		
		PanelMovil panel1 = new PanelMovil("/img/Plato2.JPG", "              Peach Paradise", "        			               $5.50");
		panel3.add(panel1);
		
		PanelMovil panel2 = new PanelMovil("/img/Plato3.JPG", "                 Rose Blanc", "                    $5.50");
		panel3.add(panel2);
		
		PanelMovil panel4 = new PanelMovil("/img/Plato4.JPG", "      Jasmine Creme Brulee", "                    $5.50");
		panel3.add(panel4);
		
		panel3.setBorder(BorderFactory.createEmptyBorder(0, 200, 0, 200));
		add(panel3);
		
		JPanel panel6 = new JPanel();
		panel6.setBackground(Color.WHITE);
		JLabel lbl4 = new JLabel(new ImageIcon(getClass().getResource("/img/Comments.png")));
		lbl4.setAlignmentX(RIGHT_ALIGNMENT);
		panel6.add(lbl4);
		add(panel6);
		
		JLabel lb = new JLabel("INSTAGRAM");
		lb.setFont(new Font("Baskerville Old Face", Font.BOLD, 40));
		lb.setForeground(Color.decode("#5D2313"));
		lb.setAlignmentX(CENTER_ALIGNMENT);
		add(lb);
		
		JPanel exoticPanel = new JPanel();
		exoticPanel.setLayout(new GridLayout(2, 3));
		
		JButton btn1 = new JButton(new ImageIcon(getClass().getResource("/img/btn1.JPG")));
		btn1.setOpaque(false);
		btn1.setContentAreaFilled(false);
		btn1.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		exoticPanel.add(btn1);
		
		JButton btn2 = new JButton(new ImageIcon(getClass().getResource("/img/btn2.JPG")));
		btn2.setOpaque(false);
		btn2.setContentAreaFilled(false);
		btn2.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		exoticPanel.add(btn2);
		
		JButton btn3 = new JButton(new ImageIcon(getClass().getResource("/img/btn3.JPG")));
		btn3.setOpaque(false);
		btn3.setContentAreaFilled(false);
		btn3.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		exoticPanel.add(btn3);
		
		JButton btn4 = new JButton(new ImageIcon(getClass().getResource("/img/btn4.JPG")));
		btn4.setOpaque(false);
		btn4.setContentAreaFilled(false);
		btn4.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		exoticPanel.add(btn4);
		
		JButton btn5 = new JButton(new ImageIcon(getClass().getResource("/img/btn5.JPG")));
		btn5.setOpaque(false);
		btn5.setContentAreaFilled(false);
		btn5.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		exoticPanel.add(btn5);
		
		JButton btn6 = new JButton(new ImageIcon(getClass().getResource("/img/bnt6.JPG")));
		btn6.setOpaque(false);
		btn6.setContentAreaFilled(false);
		btn6.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		exoticPanel.add(btn6);
		
		exoticPanel.setBorder(BorderFactory.createEmptyBorder(0, 155, 0, 155));
		setBackground(Color.WHITE);
		exoticPanel.setBackground(Color.WHITE);
		add(exoticPanel);
	}
}
