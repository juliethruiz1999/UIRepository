package view;

import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class SignMidPanel extends JPanel{
	
	private static final long serialVersionUID = 1L;
	SignWhitePanel signWhitePanel = new SignWhitePanel();
	
	public SignMidPanel() {
//		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		signWhitePanel.setBorder(BorderFactory.createEmptyBorder(0, 40, 0, 40));
		add(signWhitePanel);
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		ImageIcon img = new ImageIcon(getClass().getResource("/img/teaBackground.PNG"));
		g.drawImage(img.getImage(), 0, 0, getWidth(), getHeight(), null);
		this.repaint();
		
	}
}
