package view;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class SignTeasPanelCard extends JPanel{
	

	private static final long serialVersionUID = 1L;

	public SignTeasPanelCard() {

		setLayout(new GridLayout(2, 4));
		setBorder(BorderFactory.createEmptyBorder(0, 200, 0, 200));
		setBackground(Color.WHITE);
		
		SignTeasPanel panel = new SignTeasPanel("/img/oneTea.PNG", "            Jasmine Creme Brulee", "                $5.50");
		add(panel);
		
		SignTeasPanel panel1 = new SignTeasPanel("/img/twoTea.PNG", "              Hawaiian Hibiscus", "        			               $5.50");
		add(panel1);
		
		SignTeasPanel panel2 = new SignTeasPanel("/img/threeTea.PNG", "                 Lavender Parfait", "                    $5.50");
		add(panel2);

		SignTeasPanel panel3 = new SignTeasPanel("/img/fourTea.PNG", "                 Spiced Apple", "                    $5.50");
		add(panel3);
		

		SignTeasPanel panel4 = new SignTeasPanel("/img/sixImage.PNG", "                 Rose Blanc", "                    $5.50");
		add(panel4);

		SignTeasPanel panel5 = new SignTeasPanel("/img/fiveImage.PNG", "                 Peach Paradise", "                    $5.50");
		add(panel5);
		
	}
}
