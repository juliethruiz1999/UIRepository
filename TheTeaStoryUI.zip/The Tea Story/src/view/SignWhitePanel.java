package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SignWhitePanel extends JPanel{
	
	
	private static final long serialVersionUID = 1L;

	public SignWhitePanel() {
		setBackground(Color.WHITE);
//		setLayout(new BorderLayout());
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JLabel labelitoLogo = new JLabel ("SIGNATURE BLENDS");
		labelitoLogo.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		labelitoLogo.setForeground(Color.decode("#5D2313"));
		labelitoLogo.setAlignmentX(CENTER_ALIGNMENT);
		labelitoLogo.setBorder(BorderFactory.createEmptyBorder(50, 10, 20, 10));
		add(labelitoLogo);
//		repaint();
		
		SignTeasPanelCard signTeasPanel = new SignTeasPanelCard();
		signTeasPanel.setBackground(new Color(255, 255, 255, 3));
		add(signTeasPanel);
		
	}
}
