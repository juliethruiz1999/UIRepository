package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelBottom extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public PanelBottom(String txt1, String txt2, String txt3) {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setOpaque(false);
		
		JLabel lbl = new JLabel(txt1);
		lbl.setFont(new Font("Arial", Font.BOLD, 17));
		lbl.setForeground(Color.WHITE);
		add(lbl);
		
		JLabel linea = new JLabel(new ImageIcon(getClass().getResource("/img/lineatita.JPG")));
		linea.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		add(linea);
		
		JLabel cntc = new JLabel(txt2);
		cntc.setFont(new Font("Arial", Font.PLAIN, 15));
		cntc.setForeground(Color.WHITE);
		cntc.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
		add(cntc);
		
		JLabel stores = new JLabel(txt3);
		stores.setFont(new Font("Arial", Font.PLAIN, 15));
		stores.setForeground(Color.WHITE);
		add(stores);
	}
}
