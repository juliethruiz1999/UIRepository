package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelBanner extends JPanel{

	private static final long serialVersionUID = 1L;

	public PanelBanner() {
		JPanel panelito = new JPanel();
		panelito.setLayout(new BoxLayout(panelito, BoxLayout.Y_AXIS));
		panelito.setBackground(Color.WHITE);
		JLabel labelitoLogo = new JLabel ("SYMPHONY IN EVERY SIP");
		labelitoLogo.setFont(new Font("Baskerville Old Face", Font.BOLD, 50));
		labelitoLogo.setForeground(Color.decode("#5D2313"));
		labelitoLogo.setBorder(BorderFactory.createEmptyBorder(50, 10, 20, 10));
		panelito.add(labelitoLogo);
		
		panelito.setOpaque(false);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		JLabel lbl = new JLabel("                      ");
		panel.setOpaque(false);
		panel.add(lbl);
		JButton viewMore = new JButton("VIEW MORE");
		viewMore.setOpaque(false);
		viewMore.setCursor(new Cursor(Cursor.HAND_CURSOR));
		viewMore.setFocusable(false);
		viewMore.setFont(new Font("Baskerville Old Face", 0, 20));
		viewMore.setContentAreaFilled(false);
		panel.add(viewMore);
		panelito.add(panel);
		
		JLabel lbe1 = new JLabel(" ");
		lbe1.setBorder(BorderFactory.createEmptyBorder(20, 0, 300, 0));
		panelito.add(lbe1);
		add(panelito);
		
		
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponents(g);
		ImageIcon font = new ImageIcon(getClass().getResource("/img/BanerTea.png"));
		g.drawImage(font.getImage(), 0, 0,getWidth(),getHeight(), null);
		
	}
}
