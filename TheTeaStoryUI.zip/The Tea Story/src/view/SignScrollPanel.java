package view;

import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class SignScrollPanel extends JPanel{
	
	private static final long serialVersionUID = 1L;

	public SignScrollPanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		SignMidPanel signMainPanel = new SignMidPanel();
		signMainPanel.setBackground(Color.WHITE);
		add(signMainPanel);
		
		PanelSouth panelSouth = new PanelSouth();
		add(panelSouth);
		

	}

}
