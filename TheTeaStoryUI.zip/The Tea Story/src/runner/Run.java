package runner;

import controller.ControllerApp;

public class Run {
	
	public static void main(String[] args) {
		new ControllerApp();
	}

}
